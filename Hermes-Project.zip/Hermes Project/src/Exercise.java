public class Exercise {
    private String textToType; // The text that the user should type
    private int timeLimit; // The time limit for the exercise in seconds

    public Exercise(String textToType, int timeLimit) {
        this.textToType = textToType;
        this.timeLimit = timeLimit;
    }

    // getters and setters
    public String getTextToType() {
        return textToType;
    }

    public void setTextToType(String textToType) {
        this.textToType = textToType;
    }

    public int getTimeLimit() {
        return timeLimit;
    }

    public void setTimeLimit(int timeLimit) {
        this.timeLimit = timeLimit;
    }
}
