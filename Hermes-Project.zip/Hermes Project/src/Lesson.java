import java.util.List;

public class Lesson {
    private String title;
    private String description;
    private List<Exercise> exercises;

    public Lesson(String title, String description, List<Exercise> exercises) {
        this.title = title;
        this.description = description;
        this.exercises = exercises;
    }

    // getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Exercise> getExercises() {
        return exercises;
    }

    public void setExercises(List<Exercise> exercises) {
        this.exercises = exercises;
    }

    // Add an exercise to the lesson
    public void addExercise(Exercise exercise) {
        exercises.add(exercise);
    }
}
